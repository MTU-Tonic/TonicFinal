package agents;

import estimation.Estimator3_6;
import ginrummy.Card;
import ginrummy.GinRummyPlayer;
import ginrummy.GinRummyUtil;
import statsStuff.GameCountUtil;

import java.util.ArrayList;
import java.util.Random;

/**
 * Estimator agent: Estimator3_6.java
 * Main strategies:
 *      - Pick up faceup card to complete melds, knock, or form a pair early in the game
 *      - Choose discard after removing cards we want to keep (melds and pairs) as well as cards we believe the opponent
 *        may find useful
 *      - Knock with variable deadwood less than or equal to 10 based on number of turn into the game
 * @authors Sarah Larkin & William Collicott
 */
public class Tonic implements GinRummyPlayer {
    private int playerNum;
    private int startingPlayerNum;
    private ArrayList<Card> cards = new ArrayList<Card>();
    private Random random = new Random();
    private boolean opponentKnocked = false;
    Card faceUpCard, drawnCard;
    ArrayList<Long> drawDiscardBitstrings = new ArrayList<Long>();
    public Estimator3_6 estimator = new Estimator3_6(0.9, 0.7, 0.7);
    Card discardLeavingLE_MaxDW;
    int MAX_DEADWOOD = 10;

    /**
     * Starts the current hand and includes initialization logic for estimator
     * @param playerNum player's 0-based player number (0/1)
     * @param startingPlayerNum starting player number (0/1)
     * @param cards dealt cards
     */
    @Override
    public void startGame(int playerNum, int startingPlayerNum, Card[] cards) {
        this.playerNum = playerNum;
        this.startingPlayerNum = startingPlayerNum;
        this.cards.clear();
        for (Card card : cards) {
            this.cards.add(card);
        }
        opponentKnocked = false;
        drawDiscardBitstrings.clear();
        estimator.initEstimator(cards);
    }

    /**
     * Return true if card would make a meld, result in a discard leaving <= MAX_DEADWOOD, or if it forms one or more
     * pairs early in the hand.
     * @param card face-up card on the draw pile
     * @return whether to pick up the faceup card
     */
    @Override
    public boolean willDrawFaceUpCard(Card card) {
        this.faceUpCard = card;
        discardLeavingLE_MaxDW = null;
        int minDW = Integer.MAX_VALUE;

        /* Will it form a meld with cards currently in our hand? */
        ArrayList<Card> newCards = (ArrayList<Card>) cards.clone();
        newCards.add(card);
        ArrayList<ArrayList<ArrayList<Card>>> melds = GinRummyUtil.cardsToBestMeldSets(newCards);
        if(melds.size() == 0) {
            return false;
        } else {
            for (ArrayList<Card> meld : melds.get(0)) {
                if (meld.contains(card)) {
                    return true;
                }
            }
        }

        /* Leave <= MAX_DEADWOOD deadwood */
        ArrayList<Card> unmeldedCards = createUnmeldedList(newCards);
        for (Card c : unmeldedCards) {
            if (c == this.faceUpCard) {
                continue;
            } else {
                ArrayList<Card> temp = (ArrayList<Card>) unmeldedCards.clone();
                temp.remove(c);
                int dw;
                dw = GinRummyUtil.getDeadwoodPoints(temp);

                if(dw <= MAX_DEADWOOD && dw < minDW) {
                    minDW = dw;
                    discardLeavingLE_MaxDW = c;
                }
            }
        }
        if(discardLeavingLE_MaxDW != null) {
            return true;
        }

        /* If we were dealt a hand that's already 100% melded, pick up a face down card
          (assume that we will immediately discard it).  */
        Card highestDWCard = findHighestDeadwoodCard(unmeldedCards);
        if (highestDWCard == null) {
            return false;
        }

        /* If the hand is only a certain number of turns old, and if we don't have pairs in a certain range, pick up the
         face-up card if it forms one or more pairs. */
        ArrayList<Card> newUnmelded = createUnmeldedList(cards);
        int minPairs = 0;
        switch(newUnmelded.size()) {
            case 10:
            case 9:
                minPairs = 3;
                break;
            case 8:
            case 7:
            case 6:
                minPairs = 2;
                break;
            case 5:
            case 4:
            case 3:
                minPairs = 1;
                break;
        }
        int maxDWSum = 18;
        int pairsBeforePretendPickup = countPairs(newUnmelded, maxDWSum);
        if (GameCountUtil.handDepth() <= 1 && (pairsBeforePretendPickup <= minPairs) && dwOf(card) < 10) {
            ArrayList<Card> tempNewHand = (ArrayList<Card>) cards.clone();
            tempNewHand.add(card);
            int pairsAfterPretendPickup = countPairs(createUnmeldedList(tempNewHand), maxDWSum);
            if (pairsAfterPretendPickup > pairsBeforePretendPickup) {
                return true;
            }
        }
        return false;
    }

    /**
     * Note which card was drawn and update opponent hand estimation as appropriate.
     * @param playerNum - player drawing a card
     * @param drawnCard - the card drawn or null, depending on whether the card is known to the player or not, respectively.
     */
    @Override
    public void reportDraw(int playerNum, Card drawnCard) {
        if (playerNum == this.playerNum) {
            cards.add(drawnCard);
            this.drawnCard = drawnCard;
        } else {
            estimator.draw(drawnCard);
        }
    }

    /**
     * Chooses and returns the best card to discard based on a series of filters
     * @return the card to be discarded
     */
    @Override
    public Card getDiscard() {
        /* Already selected during pickup of faceup card */
        if (discardLeavingLE_MaxDW != null) {
            return discardLeavingLE_MaxDW;
        }

        ArrayList<Card> unmeldedCards = createUnmeldedList(cards);

        /* If all the cards are melded, find a meld of >= 4 cards and remove one of its cards (that won't break it up).
         Since there will for certain be a meld of at least 4 if all the cards are melded, we are guaranteed to find a
         meld of at least 4 cards. */
        if (unmeldedCards.size() == 0) {
            ArrayList<ArrayList<ArrayList<Card>>> melds = GinRummyUtil.cardsToBestMeldSets(cards);
            for(ArrayList<Card> list : melds.get(0)) {
                if(list.size() >= 4) {
                    if(list.get(0) == this.faceUpCard) {
                        return list.get(list.size() - 1);
                    } else {
                        return list.get(0);
                    }
                }
            }
        }

        /* Choose not to discard pairs based on how far into the hand we are and the sum of the pairs' deadwood */
        ArrayList<Card> unmelded = (ArrayList<Card>) unmeldedCards.clone();
        if(GameCountUtil.handDepth() < 2) {
            unmelded = removePairs((ArrayList<Card>) unmeldedCards.clone(), 999);
            unmelded = removeCardsCloseToExistingMelds((ArrayList<Card>) unmelded.clone());
        } else if(GameCountUtil.handDepth() < 4) {
            unmelded = removePairs((ArrayList<Card>) unmeldedCards.clone(), 12);
        } else if(GameCountUtil.handDepth() < 5) {
            unmelded = removePairs((ArrayList<Card>) unmeldedCards.clone(), 10);
        }

        /* Do not discard cards that would give the opponent an advantage */
        unmelded = removeOpponentDesiredCards((ArrayList<Card>) unmelded.clone());
        Card discard = findHighestDeadwoodCard(unmelded);
        if(discard == null) {
            return findHighestDeadwoodCard(unmeldedCards);
        }
        return discard;
    }

    /**
     * Remove given card from cards if playerNum is this player; otherwise update the opponent hand estimation.
     * Also, increment the turns taken if playerNum is this player and reset the value of MAX_DEADWOOD based on the
     * number of turns that have passed.
     * @param playerNum the discarding player
     * @param discardedCard the card that was discarded
     */
    @Override
    public void reportDiscard(int playerNum, Card discardedCard) {
        GameCountUtil.takeTurn(this.playerNum, playerNum);
        if(GameCountUtil.handDepth() >= 7) {
            MAX_DEADWOOD = 4;
        } else if(GameCountUtil.handDepth() >= 6) {
            MAX_DEADWOOD = 6;
        } else if(GameCountUtil.handDepth() >= 5) {
            MAX_DEADWOOD = 8;
        }

        if (playerNum == this.playerNum) {
            cards.remove(discardedCard);
        } else {
            estimator.discard(discardedCard);
        }
    }

    /**
     * Check if deadwood of maximal meld is low enough to go out.
     * @return list of melds
     */
    @Override
    public ArrayList<ArrayList<Card>> getFinalMelds() {
        ArrayList<ArrayList<ArrayList<Card>>> bestMeldSets = GinRummyUtil.cardsToBestMeldSets(cards);
        if (!opponentKnocked && (bestMeldSets.isEmpty() || GinRummyUtil.getDeadwoodPoints(bestMeldSets.get(0), cards) > MAX_DEADWOOD))
            return null;
        return bestMeldSets.isEmpty() ? new ArrayList<ArrayList<Card>>() : bestMeldSets.get(random.nextInt(bestMeldSets.size()));
    }

    @Override
    public void reportFinalMelds(int playerNum, ArrayList<ArrayList<Card>> melds) {
        // Melds ignored by simple player, but could affect which melds to make for complex player.
        if (playerNum != this.playerNum) {
            opponentKnocked = true;
        }
    }

    /**
     * Note the end of this hand and reset MAX_DEADWOOD to 10 for the start of the next hand
     * @param scores current player scores, indexed by 0-based player number
     */
    @Override
    public void reportScores(int[] scores) {
        GameCountUtil.endHand();
        GameCountUtil.endGame(scores, this.playerNum);
        MAX_DEADWOOD = 10;
    }

    @Override
    public void reportLayoff(int playerNum, Card layoffCard, ArrayList<Card> opponentMeld) {
        // Ignored by simple player, but could affect strategy of more complex player.
    }

    @Override
    public void reportFinalHand(int playerNum, ArrayList<Card> hand) {
        // Ignored by simple player, but could affect strategy of more complex player.
    }

    /**
     * Generate a list of cards in your hand that are not part of a meld set
     * @param currentHand
     * @return list of cards in the hand that are not part of a meld
     */
    public ArrayList<Card> createUnmeldedList(ArrayList<Card> currentHand) {
        ArrayList<ArrayList<ArrayList<Card>>> m = GinRummyUtil.cardsToBestMeldSets(currentHand);
        if (m.size() == 0) {
            return currentHand;
        } else {
            ArrayList<Card> flat = flattenList(m.get(0));
            ArrayList<Card> unmelded = (ArrayList<Card>) currentHand.clone();
            unmelded.removeAll(flat);
            return unmelded;
        }
    }

    /**
     * Create a single-dimensional ArrayList of Card objects from an ArrayList of ArrayLists of Card objects
     * Example: [[5D, 6D, 7D], [QS, QH, QC], [10S, 9D, 2H, 3H]] becomes [5D, 6D, 7D, QS, QH, QC, 10S, 9D, 2H, 3H]
     * @param list an ArrayList of ArrayLists of Card objects
     * @return return the list created
     */
    public ArrayList<Card> flattenList(ArrayList<ArrayList<Card>> list) {
        ArrayList<Card> flat = new ArrayList<>();
        for(ArrayList<Card> l : list) {
            flat.addAll(l);
        }
        return flat;
    }

    /**
     * Return the card with the highest deadwood value from a list of cards
     * @param list
     * @return
     */
    public Card findHighestDeadwoodCard(ArrayList<Card> list) {

        /* Create a list of facecards in our current hand */
        ArrayList<Card> faceCards = new ArrayList<>();
        for (Card c : list) {
            if (c.getRank() >= 9 && !c.equals(faceUpCard)) {
                faceCards.add(c);
            }
        }

        /* If we have more than one facecard, choose to keep the facecards which fit a very broad definition of a pair */
        if (faceCards.size() > 0) {
            if (faceCards.size() == 1) {
                return faceCards.get(0);
            }

            /* Evaluate the face cards to determine which of them we should keep */
            ArrayList<Card> toRemove = new ArrayList<>();
            for(int i = 0; i < faceCards.size(); i++) {
                for (int j = i + 1; j < faceCards.size(); j++) {
                    /* Add cards to toRemove that are part of a pair with the same rank or are the same suit and at most
                     two ranks apart */
                    boolean sameRank = faceCards.get(i).rank == faceCards.get(j).rank;
                    boolean sideBySide = Math.abs(faceCards.get(i).rank - faceCards.get(j).rank) == 1;
                    boolean innerStraight = Math.abs(faceCards.get(i).rank - faceCards.get(j).rank) == 2;
                    boolean sameSuit = faceCards.get(i).suit == faceCards.get(j).suit;
                    Card cardOne = faceCards.get(i);
                    Card cardTwo = faceCards.get(j);
                    if (sameRank) {
                        int numImpossible = 0;
                        for (int suit = 0; suit < Card.NUM_SUITS; suit++) {
                            if (suit == cardOne.suit || suit == cardTwo.suit) {
                                continue;
                            } else {
                                Card c = Card.getCard(cardOne.rank, suit);
                                if (estimator.isImpossible(c, faceCards)) {
                                    numImpossible++;
                                }
                            }
                        }
                        checkNumAvailable(toRemove, numImpossible, 2, faceCards.get(i), faceCards.get(j));
                    } else if (sideBySide && sameSuit && Math.max(cardOne.rank, cardTwo.rank) < 12) {
                        int numImpossible = 0;
                        Card c1 = Card.getCard(Math.min(cardOne.rank, cardTwo.rank) - 1, cardOne.suit);
                        Card c2 = Card.getCard(Math.max(cardOne.rank, cardTwo.rank) + 1, cardOne.suit);
                        if (estimator.isImpossible(c1, cards)) {
                            numImpossible++;
                        }
                        if (estimator.isImpossible(c2, cards)) {
                            numImpossible++;
                        }
                        checkNumAvailable(toRemove, numImpossible, 2, faceCards.get(i), faceCards.get(j));
                    } else if (sideBySide && sameSuit && Math.max(cardOne.rank, cardTwo.rank) == 12) {
                        int numImpossible = 0;
                        Card c = Card.getCard(Math.min(cardOne.rank, cardTwo.rank) - 1, cardOne.suit);
                        if (estimator.isImpossible(c, cards)) {
                            numImpossible++;
                        }
                        checkNumAvailable(toRemove, numImpossible, 1, faceCards.get(i), faceCards.get(j));
                    } else if (innerStraight && sameSuit) {
                        Card c = Card.getCard(Math.min(cardOne.rank, cardTwo.rank) + 1, cardOne.suit);
                        if (estimator.isImpossible(c, cards)) {

                        } else if (!toRemove.contains(faceCards.get(i))) {
                            toRemove.add(faceCards.get(i));
                        }
                        if (!toRemove.contains(faceCards.get(j))) {
                            toRemove.add(faceCards.get(j));
                        }
                    }
                }
            }

            /* Remove and return the least-paired and highest-ranked facecard */
            if (faceCards.size() - toRemove.size() == 0) {
                /* pick the highest rank from toRemove - every face card was part of some sort of pair */
                int highRank = 0;
                Card hc = null;
                for (Card c: faceCards) {
                    if (c.getRank() > highRank) {
                        hc = c;
                        highRank = c.getRank();
                    }
                }
                return hc;
            } else {
                /* pick highest from face cards remaining */
                faceCards.removeAll(toRemove);
                int highRank = 0;
                Card hc = null;
                for (Card c: faceCards) {
                    if (c.getRank() > highRank) {
                        hc = c;
                        highRank = c.getRank();
                    }
                }
                return hc;
            }
        }

        /* Remove the card with the highest deadwood value */
        int maxDecrease = Integer.MIN_VALUE;
        Card maxDWCard = null;
        for(Card c : list) {
            if(c == this.faceUpCard) {
                continue;
            } else {
                if(dwOf(c) > maxDecrease) {
                    maxDecrease = dwOf(c);
                    maxDWCard = c;
                }
            }
        }
        return maxDWCard;
    }

    /**
     * Remove 2-card 'pairs' from the provided list that fit a variable definition based on the sum of their deadwood and
     * whether it's possible to complete the pair as a meld (a pair is 2 of the cards needed to form a meld)
     * @param list
     * @param maxSum
     * @return the hand minus the cards we've classified as 'pairs' we want to keep
     */
    public ArrayList<Card> removePairs(ArrayList<Card> list, int maxSum) {
        ArrayList<Card> toRemove = new ArrayList<>(); /* List that will holds cards that are parts of 2-card melds */

        /* Remove pairs of cards that have identical ranks */
        for(int i = 0; i < list.size(); i++) {
            for(int j = i + 1; j < list.size(); j++) {
                // Add cards to toRemove that are part of a pair with the same rank or are the same suit and at most two ranks apart
                if(list.get(i).rank == list.get(j).rank || ((Math.abs(list.get(i).rank - list.get(j).rank) == 1 || Math.abs(list.get(i).rank - list.get(j).rank) == 2) && list.get(i).suit == list.get(j).suit)) {
                    if(list.get(i).rank == list.get(j).rank) {
                        // Meld of 2 are cards of the same number.
                        if(dwOf(list.get(i)) * 2 <= maxSum) {
                            handleSameRank(toRemove, list.get(i), list.get(j));
                        }
                    } else if(Math.abs(list.get(i).rank - list.get(j).rank) == 1) {
                        if(dwOf(list.get(i)) + dwOf(list.get(j)) <= maxSum) {
                            handleAdjacentPair(toRemove, list.get(i), list.get(j));
                        }
                    }
                }
            }
        }
        list.removeAll(toRemove); // Remove all 2-card melds from the list we were provided (and plan to return)
        // find highest deadwood of list
        // find highest deadwood of toRemove
        if(list.size() == 0) {
            toRemove.remove(this.faceUpCard);
            Card highest = findHighestDeadwoodCard(toRemove);
            if(highest != null) {
                list.add(highest);
            }
        }
        return list;
    }

    /**
     *  Add the two provided cards to the provided list
     * @param list
     * @param cardOne
     * @param cardTwo
     */
    public void addCards(ArrayList<Card> list, Card cardOne, Card cardTwo) {
        if(!list.contains(cardOne)) {
            list.add(cardOne);
        }
        if(!list.contains(cardTwo)) {
            list.add(cardTwo);
        }
    }

    /**
     * Add two cards to the provided list if it is still possible to obtain the 3rd card necessary for the meld. The two
     * cards provided are of the same rank. For example: 5D & 5H.
     * @param list      list of cards in hand
     * @param cardOne   the first of two cards to examine
     * @param cardTwo   the second of two cards to examine
     */
    public void handleSameRank(ArrayList<Card> list, Card cardOne, Card cardTwo) {
        int numImpossible = 0;
        for(int suit = 0; suit < Card.NUM_SUITS; suit++) {
            if(suit == cardOne.suit || suit == cardTwo.suit) {
                continue;
            } else {
                Card c = Card.getCard(cardOne.rank, suit);
                if(estimator.isImpossible(c, cards)) {
                    numImpossible++;
                }
            }
        }
        /* If numImpossible == 0, all cards that complete the meld of 2 into a meld of 3 are either in the opponent's hand or have
        been discarded. Therefore, we still want to consider discarding either of the cards involved in this pair.*/
        if(numImpossible == 0) {
            addCards(list, cardOne, cardTwo);
        }
    }



    /**
     * Add two cards to the provided list if it is still possible to obtain the 3rd card necessary for the meld. The two
     * cards provided are separated by one rank. For example: 5D & 6D.
     * @param list      list of cards in hand
     * @param cardOne   the first of two cards to examine
     * @param cardTwo   the second of two cards to examine
     */
    public void handleAdjacentPair(ArrayList<Card> list, Card cardOne, Card cardTwo) {
        if(cardOne.rank != 0 && cardTwo.rank != 0 && cardOne.rank != 12 && cardTwo.rank != 12) {
            int numImpossible = 0;
            Card c1 = Card.getCard(Math.min(cardOne.rank, cardTwo.rank) - 1, cardOne.suit);
            Card c2 = Card.getCard(Math.max(cardOne.rank, cardTwo.rank) + 1, cardOne.suit);
            if (estimator.isImpossible(c1, cards)) {
                numImpossible++;
            }
            if (estimator.isImpossible(c2, cards)) {
                numImpossible++;
            }
            if (numImpossible == 0) {
                // Both cards that can complete this meld have not been discarded. Hold on to them.
                addCards(list, cardOne, cardTwo);
            }
        }
    }

    /**
     * Remove cards from the provided list that, if discarded, would likely complete an opponent's meld.
     * @param list  cards being considered for discard
     * @return  list of cards minus any that would likely complete an opponent's meld
     */
    public ArrayList<Card> removeOpponentDesiredCards(ArrayList<Card> list) {
        ArrayList<Card> notHelpfulToOpponent = new ArrayList<>(); // Cards that would complete an opponent's meld.
        double cutOff = 0.86; // Cut-off value for removing the card.
        for(Card card : list) {
            // Check other cards of the same rank. For example: If card is KD, check KS, KC, & KH.
            int numHelpful = 0;
            for(int suit = 0; suit < Card.NUM_SUITS; suit++) {
                if(suit == card.suit) {
                    continue;
                } else {
                    Card c = Card.getCard(card.rank, suit);
                    if(estimator.getProb(c) >= cutOff) {
                        numHelpful++;
                    }
                }
            }
            if(numHelpful < 2 && !notHelpfulToOpponent.contains(card)) {
                notHelpfulToOpponent.add(card);
            }

            // Check cards on either end of the card. For example: If card is 6D, check 5D & 7D.
            numHelpful = 0;
            if(card.rank > 0 && card.rank < 12) {
                // Card is not an Ace or King.
                Card c1 = Card.getCard(card.rank - 1, card.suit);
                Card c2 = Card.getCard(card.rank + 1, card.suit);
                if (estimator.getProb(c1) >= cutOff) {
                    numHelpful++;
                }
                if (estimator.getProb(c2) >= cutOff) {
                    numHelpful++;
                }
            }
            if(numHelpful != 2 && !notHelpfulToOpponent.contains(card)) {
                notHelpfulToOpponent.add(card);
            }

            // Check two cards to the left. For example: If card is TC, check 8C & 9C.
            numHelpful = 0;
            if(card.rank > 1) {
                // Card is not an Ace or Two.
                Card c1 = Card.getCard(card.rank - 1, card.suit);
                Card c2 = Card.getCard(card.rank - 2, card.suit);
                if (estimator.getProb(c1) >= cutOff) {
                    numHelpful++;
                }
                if (estimator.getProb(c2) >= cutOff) {
                    numHelpful++;
                }
                if(numHelpful != 2 && !notHelpfulToOpponent.contains(card)) {
                    notHelpfulToOpponent.add(card);
                }
            }

            // Check to cards to the right. For example: If card is 4S, check 5S & 6S.
            numHelpful = 0;
            if(card.rank < 11) {
                // Card is not a Queen or King.
                Card c1 = Card.getCard(card.rank + 1, card.suit);
                Card c2 = Card.getCard(card.rank + 2, card.suit);
                if (estimator.getProb(c1) >= cutOff) {
                    numHelpful++;
                }
                if (estimator.getProb(c2) >= cutOff) {
                    numHelpful++;
                }
                if(numHelpful != 2 && !notHelpfulToOpponent.contains(card)) {
                    notHelpfulToOpponent.add(card);
                }
            }
        }
        return notHelpfulToOpponent;
    }

   /**
    * Remove cards from consideration of being discarded if they are two ranks away from the beginning or end or any
     * meld we currently have that is a run (so long as the card that will join them is still available).
     * @param list
    * @return  cards still in consideration for discard
     */
    public ArrayList<Card> removeCardsCloseToExistingMelds(ArrayList<Card> list) {
        ArrayList<Card> toRemove = new ArrayList<>();
        ArrayList<ArrayList<ArrayList<Card>>> melds = GinRummyUtil.cardsToBestMeldSets(cards);
        if(melds.size() == 0) {
            // Return the list passed in if there are no melds in the current hand.
            return list;
        }

        for(ArrayList<Card> meld : melds.get(0)) {
            if(meld.get(0).rank != meld.get(1).rank) {
                // Check to see if our hand contains a card two ranks less than the starting card in the run.
                if(meld.get(0).rank > 1) {
                    Card c = Card.getCard(meld.get(0).rank - 2, meld.get(0).suit); // Card we want to see if we have.
                    if(cards.contains(c) && !estimator.isImpossible(c, cards) && !toRemove.contains(c)) {
                        toRemove.add(c);
                    }
                }

                // Check to see if our hand contains a card two ranks higher than the ending card in the run.
                if(meld.get(meld.size() - 1).rank < 11) {
                    Card c = Card.getCard(meld.get(meld.size() - 1).rank + 2, meld.get(meld.size() - 1).suit); // Card we want to see if we have.
                    if(cards.contains(c) && !estimator.isImpossible(c, cards) && !toRemove.contains(c)) {
                        toRemove.add(c);
                    }
                }
            }
        }
        list.removeAll(toRemove);
        return list;
    }

    /**
     * Count the number of pairs (same rank, or adjacent with same suit) who summed deadwood is <= the maximum.
     * @param list      the hand
     * @param maxDWSum  the maximum deadwood sum of the pairs
     * @return  the number of pairs meeting the criteria
     */
    public int countPairs(ArrayList<Card> list, int maxDWSum) {
        int numPairs = 0;

        for(int i = 0; i < list.size(); i++) {
            for(int j = i + 1; j < list.size(); j++) {
                if(list.get(i).rank == list.get(j).rank || ((Math.abs(list.get(i).rank - list.get(j).rank) == 1) && list.get(i).suit == list.get(j).suit)) {
                    if((dwOf(list.get(i)) + dwOf(list.get(j)) <= maxDWSum) && (availableToPair(list.get(i), list.get(j)))) {
                        numPairs++;
                    }
                }
            }
        }
        return numPairs;
    }

    /**
     * Are the two cards given able to form a pair (can the meld be completed, are they same rank and different suit, or
     * same suit and adjacent ranks)?
     * @param one
     * @param two
     * @return whether the two cards form a pair
     */
    public boolean availableToPair(Card one, Card two) {
        if (one.suit == two.suit) {
            int j = Math.min(one.rank, two.rank);
            Card left = null;
            if (j > 1) {
                left = Card.getCard(j, one.suit);
            }
            Card right = Card.getCard(Math.max(one.rank, two.rank) + 1, one.suit);
            if (estimator.isImpossible(right, cards) && !cards.contains(right)) {
                return false;
            }
            if (left == null || (estimator.isImpossible(left, cards) && !cards.contains(left))) {
                return false;
            }
        } else {
            Card three = null;
            Card four = null;
            for (int i = 0; i < Card.NUM_SUITS; i++) {
                if (i == one.suit || i == two.suit) {
                    continue;
                }
                if (three == null) {
                    three = Card.getCard(one.rank, i);
                    continue;
                }
                if (four == null) {
                    four = Card.getCard(one.rank, i);
                }
            }
            if (estimator.isImpossible(three, cards)) {
                return false;
            }
            if (estimator.isImpossible(four, cards)) {
                return false;
            }
        }
        return true;
    }

    /**
     * Calculate the deadwood of the given card
     * @param card
     * @return the given card's deadwood
     */
    public int dwOf(Card card) {
        return Math.min(card.getRank() + 1, 10);
    }

    /**
     * Construct pairs/triangles based on whether the number of cards available to pair with the two cards is less than
     * the maximum number needed
     * @param list
     * @param numImpossible
     * @param maxImpossible
     * @param c1
     * @param c2
     */
    public void checkNumAvailable(ArrayList<Card> list, int numImpossible, int maxImpossible, Card c1, Card c2) {
        if (numImpossible < maxImpossible) {
            if (!list.contains(c1)) {
                list.add(c1);
            }
            if (!list.contains(c2)) {
                list.add(c2);
            }
        }
    }
}