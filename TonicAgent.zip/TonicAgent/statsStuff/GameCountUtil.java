package statsStuff;

import ginrummy.GinRummyUtil;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.util.*;


/**
 * Utility class to determine stats on game progression and length
 * @author Sarah Larkin
 * Date Last Modified: 06/23/2020
 */
public class GameCountUtil {

    private static ArrayList<Integer> turnsPerHand = new ArrayList<>();
    private static ArrayList<Integer> handsPerGame = new ArrayList<>();
    private static int turnIndex = 0;
    private static int prevTurnIndex = 0;
    private static int numHands = 0;
    private static int oldNumHands = 0;
    private static int numGames = 0;
    private static int files = 0;

    /**
     * End the current hand and increment variables accordingly
     */
    public static void endHand() {
        int numTurns = turnIndex - prevTurnIndex;// hope I've not got an oboe!
        turnsPerHand.add(numTurns);
        numHands++;
        prevTurnIndex = turnIndex;
    }

    /**
     * Record that I've taken a turn when I take a turn
     * @param myNum
     * @param playerNum
     */
    public static void takeTurn(int myNum, int playerNum) {
        if (myNum == playerNum) {
            turnIndex++;
        }
    }

    /**
     * How far into the hand are we in turns?
     * @return
     */
    public static int handDepth() {
        return turnIndex - prevTurnIndex;
    }

    /**
     * Record that the game has ended and print out some statistics to both the console and data files
     * @param scores
     * @param myNum
     */
    public static void endGame(int [] scores, int myNum) {
        if (scores[0] >= GinRummyUtil.GOAL_SCORE || scores[1] >= GinRummyUtil.GOAL_SCORE) {
            int numHandsGame = numHands - oldNumHands;
            handsPerGame.add(numHandsGame);
            oldNumHands = numHands;
        }
        numGames++;
    }


    /**
     * Calculate what percentage of turns per hand fall into each category and print the result to the console
     */
    public static void turnHandNums() {
        HashMap<Integer, Integer> map = new HashMap<>();
        for (int i: turnsPerHand) {
            if (map.get(i) == null) {
                map.put(i, 1);
            } else {
                map.put(i, map.get(i) + 1);
            }
        }
    }

    /**
     * Calculate the average number of hands per game
     * @return  the average number of hands per game
     */
    public static double avgHandsPerGame() {
        double hands = 0;
        for (int i: handsPerGame) {
            hands += i;
        }
        return hands / handsPerGame.size();
    }

    /**
     * Calculate the average number of turns per hand
     * @return  the average number of turns per hand
     */
    public static double avgTurnsPerHand() {
        double turns = 0;
        for (int i: turnsPerHand) {
            turns += i;
        }
        return turns/turnsPerHand.size();
    }

    /**
     * Average the number of turns per hand per game
     * @return the average
     */
    public static ArrayList<Double> avgTurnsPerHandPerGame() {
        ArrayList<Double> list = new ArrayList<>();
        int x = 0;
        for (int i = 0; i < handsPerGame.size(); i++) {
            double h = 0;
            for (int j = 0; j < handsPerGame.get(i); j++) {
                h += turnsPerHand.get(x);
                x++;
            }
            list.add(h/handsPerGame.get(i));
        }
        return list;
    }

    /**
     * Identify and return the maximum number of turns in any hand
     * @return
     */
    public static int maxTurnsPerHand() {
        int max = -1;
        for (int i: turnsPerHand) {
            if (i > max) {
                max = i;
            }
        }
        return max;
    }

    /**
     * Calculate the minimum number of turns in any hand
     * @return
     */
    public static int minTurnsPerHand() {
        int min = Integer.MAX_VALUE;
        for (int i: turnsPerHand) {
            if (i < min) {
                min = i;
            }
        }
        return min;
    }

    /**
     * Calculate the maximum number of hands in any game
     * @return
     */
    public static int maxHandsPerGame() {
        int max = -1;
        for (int i: handsPerGame) {
            if (i > max) {
                max = i;
            }
        }
        return max;
    }

    /**
     * Calculate the minimum number of hands in any game
     * @return
     */
    public static int minHandsPerGame() {
        int min = Integer.MAX_VALUE;
        for (int i: handsPerGame) {
            if (i < min) {
                min = i;
            }
        }
        return min;
    }



}
