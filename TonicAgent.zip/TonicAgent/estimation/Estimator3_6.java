package estimation;

import ginrummy.Card;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Opponent hand estimation class.  Estimates opponent hand based on a set of hyperparameters and observed draw/discard
 * actions.
 * @authors Sarah Larkin & William Collicott
 */
public class Estimator3_6 extends Estimator {

    HashMap<Card, Double> values = new HashMap<>();
    HashMap<Card, Double> probs = new HashMap<>();
    Card mostRecentDiscard = null;

    public Card getMostRecentDiscard() {
        return mostRecentDiscard;
    }

    public void setMostRecentDiscard(Card mostRecentDiscard) {
        this.mostRecentDiscard = mostRecentDiscard;
    }

    public double sigmoidTrans(double a) {
        return (1 + (Math.atan(a) / (Math.PI / 2))) / 2.0;
    }

    /**
     * Determine if the current card is impossible to get (e.g. is in the discard pile or already in our hand)
     * @param c
     * @param cards
     * @return
     */
    public boolean isImpossible(Card c, ArrayList<Card> cards) {
        if (getProb(c) <= impossibility && !cards.contains(c)) {
            return true;
        }
        return false;
    }

    double increment = 0;
    double decrement = 0;
    double decline = 0;
    double impossibility = 0;

    public Estimator3_6(double increment, double decrement, double decline) {
        this.increment = increment;
        this.decrement = decrement;
        this.decline = decline;
    }

    /**
     * Get the probability of the given card
     * @param c
     * @return
     */
    public Double getProb(Card c) {
        double a = values.get(c);
        return (1 + (Math.atan(a) / (Math.PI / 2))) / 2.0;
    }


    public void setProb(Card c) {
        if (c == null)
            return;
        probs.put(c, getProb(c));
    }

    /**
     * Initialize the estimator based on the current hand I have
     *
     * @param myHand
     */
    public void initEstimator(Card[] myHand) {

        /* Add all the cards with a 0.5 */
        for (Card c : Card.allCards) {
            values.put(c, 0.0);
        }

        /* Set the cards in my hand to have a value of negative infinity */
        for (Card card : myHand) {
            values.put(card, Double.NEGATIVE_INFINITY);
        }

        /* Set the probabilities of all the cards in probs */
        for (Card card : values.keySet()) {
            probs.put(card, sigmoidTrans(values.get(card)));
        }
    }

    /**
     * Set the probability of the opponent having the given card to be 0
     * @param c
     */
    public void setNull(Card c) {
        values.put(c, Double.NEGATIVE_INFINITY);
        probs.put(c, sigmoidTrans(values.get(c)));
    }

    /**
     * Set the probability of the opponent having the given card to be 1
     * @param c
     */
    public void setHeld(Card c) {
        values.put(c, Double.POSITIVE_INFINITY);
        probs.put(c,sigmoidTrans(values.get(c)));
    }

    /**
     * Getter for the probability map
     * @return
     */
    public HashMap<Card, Double> getProbs() {
        return probs;
    }

    /**
     * Record a "drawCard" event, updating the estimation values based on who drew and from where
     * @param drawnCard
     */
    @Override
    public void draw(Card drawnCard) {
        if (drawnCard != null) {
            setHeld(drawnCard);
            /* If opponent picks up a ten of clubs, add increment to other non-null 10's and non-1 10's
               Also add increment to 9C and JC if their location is unknown.
               If either 9C is null, add increment to JC and QC
               If JC is null, add increment to 8C and 9C */
            double increment = this.increment;

            /* Same rank different suit */
            int numPossibleMelds = 0;
            /* Find the number of the same rank that are not negative infinity */
            for (int i = 0; i < Card.NUM_SUITS; i++) {
                if (values.get(Card.getCard(drawnCard.rank, i)) > Double.NEGATIVE_INFINITY) {
                    numPossibleMelds++;
                }
            }

            /* still same rank different suit */
            /* Update them all - even the infinities - by incr * number of rank that could be in hand */
            for (int i = 0; i < Card.NUM_SUITS; i++) {
                Card c = Card.getCard(drawnCard.rank, i);
                Double tmp = values.get(c);
                values.put(c, tmp + increment * numPossibleMelds);
                probs.put(c, getProb(c));
            }

            /* Same suit, different rank */
            SurroundingCards sc = new SurroundingCards(drawnCard);
            sc.update(increment, true);
        } else {
            /* The opponent picks up a face down card (and simultaneously has turned down the face up card). */
            if(mostRecentDiscard == null) {
                /* The game starts with the opponent turning down the first face up card. However, we don't know what
                   that card was at that moment, so there is nothing we can do in this case. */
            } else {
                /* The opponent turns down a face up card, and we can see what they turned down. */
                SurroundingCards mrd = new SurroundingCards(mostRecentDiscard);
                mrd.update(this.decline * -1, false);
            }
        }
    }

    /**
     * Helper class to locate all the cards which could form melds with a given card.
     */
    private class SurroundingCards {
        Card lc = null;
        Card llc = null;
        Card rc = null;
        Card rrc = null;

        Double left = 0.0;
        Double right = 0.0;
        Double rr = 0.0;
        Double ll = 0.0;

        Card card;

        // NOTE:  hashmap.get(null) returns null!

        public SurroundingCards(Card c) {
            card = c;

            lc = EstimatorUtils.getLeftCard(c);
            rc = EstimatorUtils.getRightCard(c);
            llc = EstimatorUtils.get2LeftCard(c);
            rrc = EstimatorUtils.get2RightCard(c);

            left = values.get(lc);
            right = values.get(rc);
            rr = values.get(rrc);
            ll = values.get(llc);
        }



        /**
         * Update the cards to the left and right; use a positive value for val
         * when incrementing, and a negative value for val when decrementing.
         * @param val
         */
        public void updateVals(double val) {
            if (left != null) {
                values.put(lc, left + val);
            } else if (rr != null) {
                values.put(rrc, rr + val * val);
            }

            if (right != null ) {
                values.put(rc, right + val);
            } else if (ll != null) {
                values.put(llc, ll + val * val);
            }
        }

        /**
         * Update the probabilities
         */
        public void updateProbs() {
            setProb(lc);
            setProb(rc);
            setProb(llc);
            setProb(rrc);
        }

        /**
         * Create a "ripple" outward effect for cards if there is more than one card present for a potential meld
         * @param val
         */
        public void updateAverage(double val) {
            int i = EstimatorUtils.getLeftRankBound(card.rank - 2);
            int j = EstimatorUtils.getRightRankBound(card.rank + 2);
            for (i = i; i <= j; i++) {
                averageCard(Card.getCard(i, card.suit));
            }
        }

        /**
         * Update the values and probabilities for a given card by the given amount
         * @param val
         * @param incr
         */
        public void update(double val, boolean incr) {
            updateVals(val);
            updateProbs();
            if (incr) {
                updateAverage(val);
            }
        }

        /**
         * Create a "bonus" increment/decrement based on the likelihood of opponent holding nearby cards
         * @param c
         */
        public void averageCard(Card c) {
            int lb = EstimatorUtils.getLeftRankBound(c.rank - 1);
            int rb = EstimatorUtils.getRightRankBound(c.rank + 1);

            double l = -1;
            double r = -1;

            if (lb < c.rank)
                l = probs.get(Card.getCard(lb, c.suit));
            else
                l = 0;

            if (r > c.rank)
                r = probs.get(Card.getCard(rb, c.suit));
            else
                r = 0;

            if (l == -1)
                l = r;
            if (r == -1)
                r = l;

            double bonus = (l + r) / 2;
            double magic = 1;
            values.put(c, values.get(c) + magic * bonus);
            setProb(c);
        }
    }

    /**
     * Update the opponent hand estimation based on a "discard" event - only called when opponent discards because the opponent
     * hand probability is already set to 0 when a card is in our hand.
     * @param discardedCard
     */
    @Override
    public void discard(Card discardedCard) {
        setNull(discardedCard);

        double decr = 0.3;

        /* Same rank different suit */
        for (int j = 0; j < Card.NUM_SUITS; j++) {
            if (j != discardedCard.suit) {
                Double tmp = values.get(Card.getCard(discardedCard.rank, j));
                if (tmp != null && tmp != 1.0) {
                    values.put(Card.getCard(discardedCard.rank, j), tmp - decr);
                }
            }
        }

        /* Same suit, different rank */
        SurroundingCards sc = new SurroundingCards(discardedCard);
        sc.update(-this.decrement, false);

    }

    @Override
    public void draw(Card drawnCard, HashMap<Card, Double> opponentHand) {
// intentionally blank
    }

    @Override
    public void discard(Card discardedCard, HashMap<Card, Double> opponentHand) {
// intentionally blank
    }
}
