package estimation;

import ginrummy.*;
import java.util.HashMap;

/**
 * Abstract class for estimator methods
 * @authors Sarah Larkin & William Collicott
 */
public abstract class Estimator {

    public  void initEstimator(Card[] myHand) {

    }

    public void setNull(Card c) {

    }

    public HashMap<Card, Double> getProbs() {
        return null;
    }

    public void printOpponentHand(HashMap<Card, Double> opponentHand) {
        for (int i = 0; i < 52; i++) {
            if (i % 13 == 0)
                System.out.println();
            Double d = opponentHand.get(Card.getCard(i));
            String num = "";
            if (d != null)
                num = String.format("%.2f", d);
            else
                num = null;
            System.out.printf("%4s=%4s,", Card.getCard(i), num);
        }
        System.out.println("\nACHOO\n");
    }

    public abstract void draw(Card drawnCard, HashMap<Card, Double> opponentHand);

    public abstract void discard(Card discardedCard, HashMap<Card, Double> opponentHand);

    public abstract void draw(Card drawnCard);

    public abstract void discard(Card discardedCard);


}

