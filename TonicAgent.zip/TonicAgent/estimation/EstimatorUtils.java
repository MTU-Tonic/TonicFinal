package estimation;

import ginrummy.*;

/**
 * Utility class for estimator
 * @authors Sarah Larkin & William Collicott
 */
public class EstimatorUtils {

    public static final int LEFT_RANK_BOUND  = 0;
    public static final int RIGHT_RANK_BOUND = 12;

    /**
     * Utility method to create the left card of a given card (within the same suit, ascending order)
     * @param c     the card given
     * @return      the next lowest card in the suit if it exists, or null
     */
    public static Card getLeftCard(Card c) {
        if (c == null)
            return null;
        Card left = null;
        if (c.getRank() - 1 >= 0)
            left = Card.getCard(c.getRank() - 1, c.getSuit());
        return left;
    }

    /**
     * Utility method to create the right card of a given card (within the same suit, ascending order)
     * @param c     the card given
     * @return      the next highest card in the suit if it exists, or null
     */
    public static Card getRightCard(Card c) {
        Card right = null;
        if (c.getRank() + 1 < 13)
            right = Card.getCard(c.getRank() + 1, c.getSuit());
        return right;
    }

    /**
     * Gets the card two cards to the left of the current card within the same suit.
     * @param c     the current card
     * @return      the card two cards to the left or null
     */
    public static Card get2LeftCard(Card c) {
        if (c == null)
            return null;
        if (c.rank - 2 < LEFT_RANK_BOUND)
            return null;
        return Card.getCard(c.rank - 2, c.suit);
    }

    /**
     * Gets the card two cards to the right of the current card within the same suit.
     * @param c     the current card
     * @return      the card two cards to the right or null
     */
    public static Card get2RightCard(Card c) {
        if (c == null)
            return null;
        if (c.rank + 2 > RIGHT_RANK_BOUND)
            return null;
        return Card.getCard(c.rank + 2, c.suit);
    }

    /**
     * Get the leftmost rank bound of LEFT_RANK_BOUND and the given rank
     * @param i     the given rank to test
     * @return      i or LEFT_RANK_BOUND
     */
    public static int getLeftRankBound(int i) {
        if (i >= 0)
            return i;
        else
            return LEFT_RANK_BOUND;
    }

    /**
     * Get the rightmost rank bound of RIGHT_RANK_BOUND and the given rank
     * @param i     the given rank to test
     * @return      i or RIGHT_RANK_BOUND
     */
    public static int getRightRankBound(int i) {
        if (i < 13)
            return i;
        else
            return RIGHT_RANK_BOUND;
    }

}
